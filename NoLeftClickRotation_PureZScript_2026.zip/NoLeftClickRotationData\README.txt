NoLeftClickRotation（禁用左键视图旋转）
========================================

版本：ZBrush 2026（纯 ZScript 版，不依赖 Python）
格式：官方 ZPlugin（.zsc + 支持目录）

功能
----
在 ZBrush 雕刻（Edit 模式）下，禁用“左键按住空白画布拖动触发视图旋转”。
左键点击本身完全不会被拦截，界面上的滑块、按钮、画布内的自定义 UI 都
可以正常拖动；光标从空白处拖到模型上时，笔刷会从进入点正常起笔。
右键拖动缩放、中键拖动平移不受影响。

原理（纯 ZScript，无 Python）
----------------------------
1. DLL 只在本进程内子类化 ZBrush 主窗口，随 ZBrush 启动和退出，不做任何
   开机启动项。
2. .zsc 脚本用官方 [Sleep] 事件循环监听鼠标移动/左键按下，每次事件时读取
   Edit 状态（[IGet,Transform:Edit]）、光标位置（[MouseHPos/MouseVPos]）、
   画布范围（[IGet,Document:Width/Height]）和光标下的材质索引
   （[PixolPick,5,h,v]，0=空白画布，不比较颜色），并通过官方
   [FileExecute] 接口把结果同步给 DLL。
3. 左键按下时，DLL 仅在“Edit 模式 + 空白画布 + ZBrush 画布光标（非标准
   系统光标）”时，放行点击后立即补发一次左键抬起，在旋转开始前取消这次
   拖拽；滑块、按钮等界面控件使用标准系统光标，不会被处理。
4. 从空白处拖到模型上时，脚本持续跟踪光标下的材质索引，DLL 在光标进入
   模型后补发一次左键按下，笔刷从进入点正常起笔；画笔的运动消息从未被
   拦截。
5. 带修饰键的拖动（Ctrl+左键框选遮罩、Shift/Alt+左键等）一律不处理，
   原样交给 ZBrush。
6. 如果脚本轮询停止（超过 3 秒未更新），DLL 自动回到“不干预”状态，不会
   用旧数据误拦截。

文件结构
--------
ZStartup\ZPlugs64\NoLeftClickRotation.zsc
ZStartup\ZPlugs64\NoLeftClickRotationData\NoLeftClickRotation.dll
ZStartup\ZPlugs64\NoLeftClickRotationData\config.txt（启用状态）
ZStartup\ZPlugs64\NoLeftClickRotationData\README.txt

安装方法（手动安装，无安装程序）
--------------------------------
1. 关闭 ZBrush。
2. 打开 ZBrush 用户资产目录：
   ZBrush 菜单 → Preferences（偏好设置）→ Asset Directory（资产目录）
   → Open Directory（打开目录）。
   也可以手动进入：
   C:\Users\[你的用户名]\AppData\Roaming\Maxon\Maxon ZBrush 2026_F3C8B4C4\
3. 进入其中的 ZStartup\ZPlugs64 文件夹（没有就手动创建）。
4. 把 NoLeftClickRotation.zsc 和 NoLeftClickRotationData 文件夹一起复制
   进去，保持上面的目录结构。
5. 重新启动 ZBrush。
6. 打开 Z插件 菜单 → NoLeftClickRotation → Enable。

重要说明：这是纯 ZScript 版，界面文字目前固定为英文。ZBrush 的 ZScript
文本解析器不支持用非 ASCII 字符创建中文面板/按钮名；需要中文界面时请
使用 Python 桥接版（旧插件架构），核心功能与纯 ZScript 版一致。

卸载
----
关闭 ZBrush，删除 ZPlugs64 下的 NoLeftClickRotation.zsc 和
NoLeftClickRotationData 文件夹即可。不写入系统环境变量，不影响开机启动。

说明
----
- 纯 ZScript 版界面固定为英文：NoLeftClickRotation → Enable。
- 不修改视图变换，不产生画布残影；如果遇到任何画布残留，Ctrl+N 清空
  画布即可恢复。
- 本插件不修改 ZBrush 安装目录，也不修改任何模型数据。
- 如果 ZBrush 更新后插件失效，按上面步骤重新复制一次即可。
