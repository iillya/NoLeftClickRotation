No Left Click Rotation (ZScript 版) v1.0.0
===========================================

功能：在 ZBrush 编辑模式下锁定相机，避免左键从模型外的空白画布
拖动时旋转视图；右键按住期间临时解锁相机，松开 2ms 后恢复锁定。
模型上左键正常雕刻，支持从空白处拖入模型自动起笔，保留 LightBox
单击/双击/拖动。

安装
----
1. 完全关闭 ZBrush。
2. 把本目录中的 ZPlugs64 文件夹整体复制到当前 ZBrush 版本的用户
   启动目录下（合并 ZPlugs64 内容）：

   %APPDATA%\Maxon\Maxon ZBrush 2026_*\ZStartup\

   最终应包含：
   ZStartup\ZPlugs64\NoLeftClickRotation2022.txt
   ZStartup\ZPlugs64\NoLeftClickRotation2022Data\NoLeftClickRotation2022.dll

3. 重新启动 ZBrush（ZBrush 会在启动时自动编译并加载插件）。
4. 打开 Zplugin > No Left Click Rotation，确认 Enable 已开启。

升级 / 覆盖安装
---------------
覆盖安装前，先删除 ZPlugs64 目录中的旧文件：
- NoLeftClickRotation2022.txt
- NoLeftClickRotation2022.zsc（编译缓存，删除后会重新生成）
- NoLeftClickRotation2022Data 文件夹

卸载
----
关闭 ZBrush 后，删除上述三个文件/文件夹。

注意
----
- 只保留一份插件文件，不要同时安装旧版本。
- 若同时使用 Python 版，请二选一，避免两个版本互相干扰。
