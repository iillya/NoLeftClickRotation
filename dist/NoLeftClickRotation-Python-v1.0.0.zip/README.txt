No Left Click Rotation (Python 版) v1.0.0
===========================================

功能：在 ZBrush 编辑模式下锁定相机，避免左键从模型外的空白画布
拖动时旋转视图；右键按住期间临时解锁相机，松开 2ms 后恢复锁定。
模型上左键正常雕刻，支持从空白处拖入模型自动起笔，保留 LightBox
单击/双击/拖动。

设置（Zplugin > No Left Click Rotation）
----------------------------------------
- Enable：插件总开关。关闭后完全不再碰相机（恢复解锁），所有
  处理停止。
- Camera Lock：相机锁定开关。关闭时完全不碰 Draw:Lock Camera，
  右键原样放行不处理，左键仍照常处理。
- BiliBli：跳转作者 B 站首页。
- Github：打开插件 GitHub 仓库。
- 空白拖入模型的起笔延时固定为 1ms。

安装
----
1. 完全关闭 ZBrush。
2. 把本目录中的 NoLeftClickRotation.py 复制到当前 ZBrush 版本的
   用户插件目录：

   %APPDATA%\Maxon\Maxon ZBrush 2026_*\ZStartup\ZPlugs64\

3. 重新启动 ZBrush。
4. 打开 Zplugin > No Left Click Rotation，确认「启用」已开启。

卸载
----
关闭 ZBrush 后，从上述目录删除 NoLeftClickRotation.py。

注意
----
- 只保留一份插件文件，不要同时安装旧版本。
- 若同时使用 ZScript 版，请二选一，避免两个版本互相干扰。
