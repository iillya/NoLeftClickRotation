No Left Click Rotation (Python 版) v1.0.0
===========================================

功能：在 ZBrush 编辑模式下锁定相机，避免左键从模型外的空白画布
拖动时旋转视图；右键按住期间临时解锁相机，松开 2ms 后恢复锁定。
模型上左键正常雕刻，支持从空白处拖入模型自动起笔，保留 LightBox
单击/双击/拖动。

安装
----
1. 完全关闭 ZBrush。
2. 把本目录中的 NoLeftClickRotation.py 复制到当前 ZBrush 版本的
   用户插件目录：

   %APPDATA%\Maxon\Maxon ZBrush 2026_*\ZStartup\ZPlugs64\

3. 重新启动 ZBrush。
4. 打开 Zplugin > No Left Click Rotation > V1，确认 Enable 已开启。

卸载
----
关闭 ZBrush 后，从上述目录删除 NoLeftClickRotation.py。

注意
----
- 只保留一份插件文件，不要同时安装旧版本。
- 若同时使用 ZScript 版，请二选一，避免两个版本互相干扰。
